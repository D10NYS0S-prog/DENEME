var requests = {
    check: []
}
let systemInfo = (new UAParser()).getResult();
let user_dialog = {
    /**
     *
     * @param {object} center center.mesaj innerHTML, center.buttons div elementlerden oluşan arrray.
     * @param {object} inright ikinci sayfa için center
     * @returns {object} div.datareturn değerini döndürür
     */
    show: function (center, inright) {

        return new Promise((resolve, reject) => {
            let radio = document.querySelector("input[name=dialog_state]");
            document.querySelector("input[name=dialog_state]+div .center .mesaj").innerHTML = center.mesaj;
            center.buttons.forEach((value, key) => {
                document.querySelector("input[name=dialog_state]+div .center .dlg-prompt").appendChild(value);
                value.addEventListener('click', async function (elem) {
                    let der;
                    if (value.onfunc != null) {
                        der = await value.onfunc();
                    }
                    if (der != undefined) {
                        resolve(der);
                    }

                });
            });
            if (inright) {
                document.querySelector("input[name=dialog_state]+div .inright .mesaj").innerHTML = inright.mesaj;
                inright.buttons.forEach((value, key) => {
                    document.querySelector("input[name=dialog_state]+div .inright .dlg-prompt").appendChild(value);
                    value.addEventListener('click', async function (elem) {
                        let der;
                        if (value.onfunc != null) {
                            der = await value.onfunc();
                        }
                        if (der != undefined) {
                            resolve(der);
                        }

                    });
                });
            }
            radio.click();

        });

    },
    next: function (params) {
        document.querySelectorAll(".dlg-content.center").forEach(function (params) {
            params.classList.add("inleft");
            params.classList.remove("center");

        })
        document.querySelectorAll(".dlg-content.inright").forEach(function (params) {
            params.classList.remove("inright");
            params.classList.add("center");
        })
    },
    prev: function (params) {
        document.querySelectorAll(".dlg-content.center").forEach(function (params) {
            params.classList.add("inright");
            params.classList.remove("center");

        })
        document.querySelectorAll(".dlg-content.inleft").forEach(function (params) {
            params.classList.remove("inleft");
            params.classList.add("center");
        })
    },
    hide: function (params) {
        let inp = document.querySelector("input[name=dialog_state]:checked");
        if (inp) {
            inp.click();
            document.querySelector("input[name=dialog_state]+div").innerHTML = ` <div class='dlg-wrap'>
                    <div class='dlg-content center'>
                        <div class='mesaj'>

                        </div>
                        <div class='dlg-prompt'>

                        </div>
                    </div>
                    <div class='dlg-content inright'>
                        <div class='mesaj'>

                        </div>
                        <div class='dlg-prompt'>

                        </div>
                    </div>
                </div>
           
                `

        }

    }
};
let blockUILogo = {
    container: document.createElement("div"),
    show: function (genel, ayrinti, son, toblock = "body", arayaGir = false, koru = false) {
        if (arayaGir) {
            this.hide();
            blockUILogo.container.classList.add("UYP_block");
            blockUILogo.container.innerHTML = '<div><div class="lds-dual-ring"><img style="width:55px;align-self:center;" src="chrome-extension://hlgcdafdokigonljodongahofoeaedjk/style/img/logo.png" /></div><span style="margin-top: 10px;color: white;width:max-content;margin-left:auto;margin-right:auto;" id="dialog_genel" data-koru="' + koru.toString() + '">' + genel + '</span><div><span id="dialog_ayrinti" style="margin-top: 5px;color: white;">' + ayrinti + '</span><span style="margin-top: 10px;color: white;width:max-content;margin-left:auto;margin-right:auto;" id="dialog_yuzde"></span></div><div><span id="dialog_son" style="color: white;">' + son + '</span><span style="margin-top: 10px;color: white;width:max-content;margin-left:auto;margin-right:auto;" id="dialog_yuzde_son"></span></div><div>';
            document.querySelector(toblock).append(this.container);
        } else if (!this.container.isConnected) {
            blockUILogo.container.classList.add("UYP_block");
            blockUILogo.container.innerHTML = '<div><div class="lds-dual-ring"><img style="width:55px;align-self:center;" src="chrome-extension://hlgcdafdokigonljodongahofoeaedjk/style/img/logo.png" /></div><span style="margin-top: 10px;color: white;width:max-content;margin-left:auto;margin-right:auto;" id="dialog_genel" data-koru="' + koru.toString() + '">' + genel + '</span><div><span id="dialog_ayrinti" style="margin-top: 5px;color: white;">' + ayrinti + '</span><span style="margin-top: 10px;color: white;width:max-content;margin-left:auto;margin-right:auto;" id="dialog_yuzde"></span></div><div><span id="dialog_son" style="color: white;">' + son + '</span><span style="margin-top: 10px;color: white;width:max-content;margin-left:auto;margin-right:auto;" id="dialog_yuzde_son"></span></div><div>';
            document.querySelector(toblock).append(this.container);
        }

    },
    hide: function () {

        this.container.remove();

    }
};
var user = {
    avukat_id: 0,
    avukat_adi: "",
    avukat_soyadi: "",
    baro: "",
    help: {
        takip: {
            menu: {
                count: 0

            }
        },
        isNotChromeUyar: 0,
    },
    options: {
        promode: false,
        autoPDF: true,
        extensionStatus: true,
        task_list: null,
        calendar: null,
        arsiv: {
            timeout: 300000,
            active: false,
            arsivFolder: "UYAP DOSYALAR"
        },
        startUp: {
            durusmaEkle: true,
            durusmaGelecekAyi: 1,
            durusmaGelecekTarihi: null,
            satisEkle: true,
            satisGelecekHaftasi: 4,
            satisGelecekTarihi: null
        },
        kapaliDosyalariTakipEt: {
            active: false,
            lastTarihUyap: new Date().toString(),
            lastTarihYerel: new Date().toString(),
        }
    },
    _cSa: 0,
    startUp: {
        uyelikOnerTarihi: null
    },
    interrupts: {
        filedownload: {},
        insertToDosyalar: {
            dosyalar: {},
            cbsdosyalar: {},
            danistaydosyalar: {},
            yargitaydosyalar: {}
        },
        insertToEvraklar: {
            evraklar: {},
            yargitayevraklar: {},
            tebligatlar: {}
        },
        insertToDurusmalar: {},
        insertToIhaleler: {},
        insertToGorulmemis: {
            dosyalar: {},
            evraklar: {},
            tebligatlar: {}
        },
        insertToTaraflar: {},
        showToastrs: {
            tebligat: {}
        },
        tebligatCheck: {
            dosyalar: {},
            cbsdosyalar: {},
            danistaydosyalar: {},
            yargitaydosyalar: {}
        },
        sorgulaTaraf: {
            dosyalar: {},
            cbsdosyalar: {},
            danistaydosyalar: {},
            yargitaydosyalar: {}
        }
    },
    errors: {},
    evrakGorulmemis: {
        dosyalar: {},
        cbsdosyalar: {},
        danistaydosyalar: {},
        yargitaydosyalar: {}
    },
    dosyaGorulmemis: {},
    promode: {
        calisan: { username: "ADMIN", userpassword: "123456789", adi: "", soyadi: "" },
        server: { hostname: "localhost", port: 9935 },
        activated: false
    }
}
let campaign = {
    invitefriend: {
        _link: null,
        copyLink: function () {
            navigator.clipboard.writeText(this._link).then(() => {
                alert("Copied the text: " + this._link);
            })

        },
        share: function (link) {
            let _whatsappMessage = "Avukatlar%20i%C3%A7in%20harika%20bir%20eklenti%3B%0A" + encodeURIComponent(link);
            let _mailMessage = "Avukatlar%20i%C3%A7in%20harika%20bir%20eklenti%3B%0A" + encodeURIComponent(link);

            return `
 <div class="popover__wrapper" >
<a style="border: none" id="campaigns"><img style="width: 3em;cursor: pointer" src="chrome-extension://hlgcdafdokigonljodongahofoeaedjk/style/img/share.svg"> </a>
             <div class="popover__content" style="top:calc(-3em - 18px);left:-1.5em;">
                <a target="_blank" style="border: none;" 
            href="https://wa.me/?text=${_whatsappMessage}"
            data-action="share/whatsapp/share"
            ><img style="width: 3em;"
                src="chrome-extension://hlgcdafdokigonljodongahofoeaedjk/style/img/whatsapp.png"> </a>
                <a onclick="navigator.clipboard.writeText(&#39;${link}&#39;).then(ew=>alert(&#39;Link Panoya Kopyalandı&#39;))" style="border: none;cursor: pointer" title="Linki Kopyala"><img
                style="width: 3em;" src="chrome-extension://hlgcdafdokigonljodongahofoeaedjk/style/img/share-link.svg">
        </a>
            </div>
           
             </div>`
        },
        set link(link) {
            this._link = link;
            document.getElementById("temasnoktasi").insertAdjacentHTML("beforeend", this.share(link));
        }
    }
}
let isloadExtension = true;
addEventListener("message", async (event) => {
    //VERSION if (event.origin !== location.protocol+"//avukat.uyap.gov.tr") return;
    try {
        if (event.data.ask == 'startup') {

            user.avukat_id = event.data.params.id;
            user.avukat_adi = event.data.params.adi;
            user.avukat_soyadi = event.data.params.soyadi;
            user.baro = event.data.params.baro;
            if (user.avukat_id) {
                function isObject(item) {
                    return (item && typeof item === 'object');
                }

                function mergeDeep(target, source) {
                    if (isObject(target) && isObject(source)) {
                        for (const key in source) {
                            if (isObject(source[key])) {
                                if (!target[key]) {
                                    Object.assign(target, { [key]: source[key] })
                                }
                                mergeDeep(target[key], source[key]);
                            } else {
                                Object.assign(target, { [key]: source[key] });
                            }
                        }
                    }
                    return target;
                }

                campaign.invitefriend.link = `https://chromewebstore.google.com/detail/i%CC%87merek-uyap-avukat-yardi/hlgcdafdokigonljodongahofoeaedjk?utm_source=extension&utm_medium=${user.avukat_id}&utm_campaign=invitefriend`;
                let localSto = getUserLocal(user.avukat_id);
                if (localSto) {
                    user = mergeDeep(user, localSto);
                }

            }

            chrome.runtime.sendMessage({
                ask: "extensionStatus",
                status: user.options.extensionStatus
            }, function (response) {

            });
            blockUILogo.show("Sunucuya Bağlanıyor", "Lütfen İşlem Bitene Kadar Bekleyiniz", "Sunucu İle Eşitleniyor", "body", true, true);

            let database = await connectH2();
            blockUILogo.hide();
            if (database) {
                user.options.promode = database.status == 200 ? true : false
            }

            setUserLocal(user.avukat_id);
            localStorage.setItem("active_user", user.avukat_id);
            chrome.storage.local.set({ [user.avukat_id]: user, "active_user": user.avukat_id });
            chrome.storage.local.get({ userKeyIds: [] }, function (result) {
                let _uniquserKeyIds = new Set(result.userKeyIds);
                _uniquserKeyIds.add(user.avukat_id);
                chrome.storage.local.set({ userKeyIds: Array.from(_uniquserKeyIds) });
            });
            if (user.options.extensionStatus && isloadExtension) {
                await loadExtension();
            }
            event.ports[0].postMessage({ result: true });
        }
        if (event.data.ask == '_cSa') {
            user._cSa = parseInt(event.data.params._cSa);
            chrome.storage.local.set({ [user.avukat_id]: user });
            check();
            event.ports[0].postMessage({ result: true });
        }
        if (event.data.ask == 'connectH2') {
            event.ports[0].postMessage(await connectH2());
        }
        if (event.data.ask == 'database') {
            event.data.request.headers = {
                "avukat_id": user.avukat_id,
                "username": user.promode.calisan.username
            }
            let results = await chrome.runtime.sendMessage({
                ask: "database",
                url: "http://" + user.promode.server.hostname + ":" + user.promode.server.port + event.data.url,
                request: event.data.request,
            });
            event.ports[0].postMessage(results);
        }

        if (event.data.ask == 'showDefaultFolder') {

            chrome.runtime.sendMessage({
                ask: "showDefaultFolder",
                interactive: true
            })

        }
        if (event.data.ask == 'askAyarlar') {

            chrome.runtime.sendMessage({
                ask: "uyelik",
                params: {
                    avukat_id: user.avukat_id,
                    unique_id: user.response ? user.response.uyap_unique_id : null,
                    baro: user.baro,
                    browser: systemInfo.os.name + "@" + systemInfo.os.version + " - " + systemInfo.browser.name + "@" + systemInfo.browser.version,
                    promode: user.options.promode,
                    _cSa: user._cSa
                },
            }, function (response) {
                document.querySelector("#uyelik .uyeid").innerText = response.kullanimHakki.imerek_avukat_id;
                document.querySelector("#uyelik .uyeturu").innerText = response.kullanimHakki.uyap_type.indexOf("ucretli") >= 0 ? "Ücretli" : response.kullanimHakki.uyap_type.indexOf("ucretsiz") >= 0 ? "Ücretsiz" : "Ödeme Bekleniyor";
                document.querySelector("#uyelik ._csa").innerText = response.cSa
                let fr = response.kullanimHakki.uyap_type == 'ucretli' ? new Date(response.kullanimHakki.uyap_Ucretli_Son.date) : new Date(response.kullanimHakki.uyap_Ucretsiz_Son.date);
                let sonKullanim = fr.toLocaleDateString("tr-TR");

                document.querySelector("#uyelik .sonkullanim").innerText = sonKullanim;


                let sd = response.odemeler.length;
                response.odemeler.forEach(element => {
                    document.querySelector("#uyelik .kayityok").innerHTML = "<td>S.No</td><td>TAHSİLAT TARİHİ</td><td>BİTİŞ TARİHİ</td><td>KALAN SÜRE(Gün)</td><td>MEBLAĞ(₺)</td>";
                    let _odeme = new Date(element.odeme_tarihi);
                    _odeme.setHours(0, 0, 0, 0);
                    let _baslangic = new Date(element.baslangic_tarihi);
                    let _bitis = new Date(element.bitis_tarihi);
                    _bitis.setHours(23, 59, 59, 0);
                    const diffTime = _bitis - (new Date()).setHours(0, 0, 0, 0);
                    let diffDays;
                    if (diffTime > 0) {
                        diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                    } else {
                        diffDays = "Kullanım Süresi Doldu"
                    }
                    let _fgg = document.createElement("tr");
                    let _sno = document.createElement("td");
                    _sno.innerText = sd--;
                    let _odemeTD = document.createElement("td");
                    _odemeTD.innerText = _odeme.toLocaleDateString("tr-TR");
                    let _bitisTD = document.createElement("td");
                    _bitisTD.innerText = _bitis.toLocaleDateString("tr-TR");
                    let _sure = document.createElement("td");
                    _sure.innerText = diffDays.toString();
                    let _ucret = document.createElement("td");
                    _ucret.innerText = element.miktar.toString();
                    _fgg.append(_sno, _odemeTD, _bitisTD, _sure, _ucret);

                    document.querySelector("#uyelik .kayityok").after(_fgg)
                });

                sd = response.ucretsizler.length;
                response.ucretsizler.forEach(element => {
                    let _baslangic = new Date(element.baslangic_tarihi);
                    _baslangic.setHours(0, 0, 0, 0);
                    let _bitis = new Date(element.bitis_tarihi);
                    _bitis.setHours(23, 59, 59, 0);
                    const diffTime = _bitis - (new Date()).setHours(0, 0, 0, 0);
                    let diffDays;
                    if (diffTime > 0) {
                        diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                    } else {
                        diffDays = "Kullanım Süresi Doldu"
                    }

                    let _fgg = document.createElement("tr");
                    let _sno = document.createElement("td");
                    _sno.innerText = sd--;
                    let _baslaTD = document.createElement("td");
                    _baslaTD.innerText = _baslangic.toLocaleDateString("tr-TR");
                    let _bitisTD = document.createElement("td");
                    _bitisTD.innerText = _bitis.toLocaleDateString("tr-TR");
                    let _sure = document.createElement("td");
                    _sure.innerText = diffDays.toString();
                    _fgg.append(_sno, _baslaTD, _bitisTD, _sure);

                    document.querySelector("#uyelik .kayityok_ucretsiz").after(_fgg)
                    if (document.querySelector(".UYP_block") && !blockUILogo.container.isConnected) {
                        document.querySelector(".UYP_block").remove();
                    }
                });
                event.ports[0].postMessage({ result: true });
            });

        }
        if (event.data.ask == 'google_yetki_ver') {
            newAccessToken();
            event.ports[0].postMessage({ result: true });
        }
        if (event.data.ask == 'locationReload') {

            let islemeDevam = `<p><strong>ÜZGÜNÜZ! İMEREK UYAP YARDIMCISI DEVRE DIŞI BIRAKILIYOR.</strong>
                                         <br>
                                         <br>
                                        <u>İMEREK UYAP YARDIMCISI çözemediği bir hata ile karşılaştı!</u> 
                                        <br>
                                        <br>
                                        İşlemlerinize devam edebilmeniz için eklenti devre dışı bırakıldı. Daha sonra etkin hale getirerek tekrar deneyebilirsiniz.
                                   
                                         </p>`
            let tmm = document.createElement('div');
            tmm.innerText = 'Tamam';
            tmm.className = "button positive";
            tmm.onfunc = async function (params) {
                disableExtension();
                user_dialog.hide();

            }
            let _center = {
                mesaj: islemeDevam,
                buttons: [tmm],

            }
            await user_dialog.show(_center);
            event.ports[0].postMessage({ result: true });

        }
        if (event.data.ask == 'disableExtension') {
            disableExtension();
            event.ports[0].postMessage({ result: true });
        }
        if (event.data.ask == 'downloadFile') {

            let response = await chrome.runtime.sendMessage({
                ask: "downloadfile",
                fileDownload: event.data.params
            });
            if (response) {
                if (response.id > 0) {
                    window.URL.revokeObjectURL(event.data.params.url);
                    event.ports[0].postMessage({
                        result: true,
                        downloadedFile: Object.assign(event.data.params, response)
                    });
                }
            }

        }
        if (event.data.ask == 'tabligatlarToCheck') {
            let retrycount = 0;
            let ask_interval = 3000;
            let checkedTebligat = event.data.params.tebligat;
            let result = new Promise((resolve, reject) => {
                setTimeout(() => {
                    let yuzde = event.data.params.index != 0 ? event.data.params.index * 100 / event.data.params.tebligatslength : 0;
                    if (document.getElementById("dialog_son")) {
                        document.getElementById("dialog_son").innerText = "Tebligatlarınız PTT sitesinden Sorgulanıyor";
                        document.getElementById("dialog_yuzde_son").innerHTML = " ( " + Math.round(yuzde) + "% )";

                    }
                    chrome.runtime.sendMessage({
                        ask: "tebligatCheck",
                        params: {
                            avukat_id: user.avukat_id,
                            barkodNo: event.data.params.tebligat.barkodNo
                        }
                    }, (response) => {
                        try {
                            let resul = JSON.parse(response)[0];
                            switch (resul.errorMessage) {
                                case "BAŞARILI":
                                    resul.hareketDongu = resul.hareketDongu.filter(hgf => hgf.mazbata == false);
                                    let _donguSon = resul.hareketDongu.slice(-1);

                                    checkedTebligat.durum = _donguSon[0].islem_detay;
                                    checkedTebligat.lastStateTarihi = new Date(_donguSon[0].tarih.split("/").reverse().join("-") + "T" + _donguSon[0].saat);
                                    switch (_donguSon[0].aciklama) {
                                        case "TESLİM EDİLDİ":
                                            checkedTebligat.isLastState = 2;
                                            break;
                                        case "İADE":
                                            checkedTebligat.isLastState = 1;
                                            break;
                                        case "TESLİM EDİLEMEDİ":
                                            checkedTebligat.isLastState = 0
                                            break;
                                        default:
                                            break;
                                    }

                                    break;
                                case "KAYIT YOK":
                                    checkedTebligat.isLastState = 0;
                                    checkedTebligat.durum = "BARKOD NUMARASI PTT'DE KAYITSIZ";
                                    break;
                                case "Barkod HATALI":
                                    checkedTebligat.isLastState = 0;
                                    checkedTebligat.durum = "BARKOD HATALI";
                                    break;

                                default:
                                    break;
                            }
                            resolve(true);
                            return;
                        } catch (error) {
                            resolve(false);
                            return;

                        }

                    });
                }, ask_interval)
            });
            do {
                if (await result) {
                    event.ports[0].postMessage({ result: true, checkedTebligat: checkedTebligat });
                    ask_interval = 3000;
                    break;
                } else {
                    retrycount++;
                    ask_interval += 1000;
                }
            } while (retrycount < 3)
            if (retrycount > 2) {
                event.ports[0].postMessage({ result: false, checkedTebligat: checkedTebligat });
            }
        }

    } catch (e) {
        event.ports[0].postMessage({ error: e });
    }
}, false)

async function connectH2() {
    return await chrome.runtime.sendMessage({
        ask: "database",
        url: "http://" + user.promode.server.hostname + ":" + user.promode.server.port + "/connectH2",
        request: {
            method: "POST",
            headers: {
                "avukat_id": user.avukat_id,
                "username": user.promode.calisan.username
            },
            body: JSON.stringify({
                avukat_id: user.avukat_id,
                avukat_adi: user.avukat_adi,
                avukat_soyadi: user.avukat_soyadi,
                username: user.promode.calisan.username,
                useradi: user.promode.calisan.adi,
                usersoyadi: user.promode.calisan.soyadi,
                userpassword: user.promode.calisan.userpassword
            })
        }
    });

}

function getUserLocal(avukat_id) {
    let user = JSON.parse(localStorage.getItem(avukat_id + "-yeni"), (key, value) => {
        if (typeof value === "string") {
            if (value.charAt(0) == "[" && key != "aciklama") {
                try {
                    return JSON.parse(value);
                } catch (e) {
                    return value;
                }

            }
        }
        return value;
    });

    function mergeDeep(source) {
        if ((source && typeof source === 'object')) {
            for (const key in source) {

                if (source[key] && typeof source[key] === 'object') {
                    mergeDeep(source[key]);
                } else {
                    if (key.toLowerCase().indexOf("tarih") >= 0) {
                        source[key] = new Date(source[key]);
                    }

                }
            }
        }
        return source;
    }

    mergeDeep(user);
    return user;
}

function setUserLocal(avukat_id) {
    localStorage.setItem(avukat_id + "-yeni", JSON.stringify(user));
}

chrome.runtime.sendMessage({
    ask: "tabsAdd",
    class: "main"
}, async function (response) {
    if (response.tabs.main[0].id != response.sender.tab.id) {
        isloadExtension = false
    }
})


chrome.runtime.sendMessage({
    ask: "access_token"
}, (response) => {
    if (response.access_token) {
        localStorage.setItem("_token", response.access_token);
    } else {
        localStorage.removeItem("_token");
    }

});


chrome.runtime.onMessage.addListener(
    async function (request, sender, sendResponse) {
        if (request.ask == "disableExtension") {
            disableExtension();
        }
        if (request.ask == "enableExtension") {
            enableExtension();
        }
        return true;
    }
);

function newAccessToken(elem) {

    blockUILogo.show("GOOGLE Yetkilendirmesi Bekleniyor", "Lütfen İşlem Bitene Kadar Bekleyiniz", "", "body", true, true);
    chrome.runtime.sendMessage({
        ask: "new_access_token",
        interactive: true
    }, function (response) {

        if (response.access_token) {
            localStorage.setItem("_token", response.access_token);
            user_dialog.hide();
            blockUILogo.hide();

        } else if (response.message) {
            let islemeDevam = `
 <p style="clear:both" xmlns="http://www.w3.org/1999/html"><span style="display: block;text-align: center;font-weight: bold;">GOOGLE YETKİLENDİRMESİ BAŞARISIZ OLDU</span>
<br><br>
        &emsp;&emsp;UYAP AVUKAT YARDIMCISI aşağıda gerekçeleri açıklanan izinlere ihtiyaç duymaktadır. Dilerseniz izin vermeyerek bu özellikleri kullanmayabilirsiniz.
        <br>
        <br>
        <table class="izin_ihtiyaclari">
  <tr>
    <td>Google Takvim</td>
    <td>:</td>
    <td>Duruşmalarınızın GOOGLE Takviminize Eklenebilmesi</td>
  </tr>
  <tr>
    <td>Google Görev</td>
    <td>:</td>
    <td>Dosya ve Evrak Notlarınızın GOOGLE Görevlere Eklenebilmesi</td>
  </tr>
  <tr>
    <td>Google Drive(App)</td>
    <td>:</td>
    <td>Verilerinizin Yedeklenmesi</td>
  </tr>
  
</table>
  <br>
    </p>
    </p>`
            let inceledim = document.createElement('div');
            inceledim.innerText = 'İzin Verme';
            inceledim.className = "button";
            inceledim.onfunc = async function (params) {
                document.querySelector("input[name=dialog_state]").click();
                blockUILogo.hide();
                return false;
            }
            let yetki_ver = document.createElement('div');
            yetki_ver.id = "google_yetki_ver";
            yetki_ver.className = "button positive";
            yetki_ver.onfunc = async function (params) {
                newAccessToken();
                document.querySelector("input[name=dialog_state]").click();
                blockUILogo.hide();
                return true;
            }
            let center = {
                mesaj: islemeDevam,
                buttons: [inceledim, yetki_ver],

            }

            user_dialog.show(center);
        }


    });


}

function disableExtension() {
    user = getUserLocal(user.avukat_id);
    user.options.extensionStatus = false;
    setUserLocal(user.avukat_id);
    localStorage.setItem("active_user", user.avukat_id);
    window.location.reload();

}

function enableExtension() {
    user = getUserLocal(user.avukat_id);
    user.options.extensionStatus = true;
    setUserLocal(user.avukat_id);
    localStorage.setItem("active_user", user.avukat_id);
    window.location.reload();
}

function loadExtension() {

    return new Promise(async (resolve, reject) => {

        var injectedScripts = [
            {
                src: "/lib/jquery/jquery.min.js",
                type: "text/javascript"
            },
            {
                src: "/lib/ua-parser-js/ua-parser.min.js",
                type: "text/javascript"
            },
            {
                src: "/lib/xhook/xhook.js",
                type: "text/javascript"
            },
            {
                src: "/lib/pdfjs/pdf.min.mjs",
                type: "module"
            },
            {
                src: "/lib/pdfmake/pdfmake.min.js",
                type: "text/javascript"
            },
            {
                src: "/lib/pdfmake/vfs_fonts.js",
                type: "text/javascript"
            },
            {
                src: "/lib/jodit/jodit.min.js",
                type: "text/javascript"
            },
            {
                src: "/lib/glightbox/glightbox.min.js",
                type: "text/javascript"
            },
            {
                src: "/lib/sumoselect/jquery.sumoselect.min.js",
                type: "text/javascript"
            },
            {
                src: "/lib/pdf-barcode/quagga.min.js",
                type: "text/javascript"
            },
            {
                src: "/lib/pdf-barcode/pdf-barcode.min.js",
                type: "text/javascript"
            },
            {
                src: "/lib/datatables/datatables.min.js",
                type: "text/javascript"
            },
            {
                src: "/lib/pnotify/core/PNotify.js",
                type: "text/javascript"
            },
            {
                src: "/lib/pnotify/animate/PNotifyAnimate.js",
                type: "text/javascript"
            },
            {
                src: "/lib/lightgallery/js/lightgallery.umd.js",
                type: "text/javascript"
            },
            {
                src: "/lib/lightgallery/js/lg-thumbnail.umd.js",
                type: "text/javascript"
            },
            {
                src: "/lib/lightgallery/js/lg-zoom.umd.js",
                type: "text/javascript"
            },
            {
                src: "/lib/lightgallery/js/lg-fullscreen.umd.js",
                type: "text/javascript"
            },
            {
                src: "/lib/lightgallery/js/lg-rotate.umd.js",
                type: "text/javascript"
            },
            {
                src: "/lib/jszip/jszip.min.js",
                type: "text/javascript"
            }
        ];



        if (user.options.promode) {
            if (user.promode.activated == false) {
                injectedScripts = injectedScripts.concat([
                    {
                        src: "/lib/jsstore/worker_function.js",
                        type: "text/javascript"
                    },
                    {
                        src: "/lib/jsstore/jsstore.min.js",
                        type: "text/javascript"
                    },
                    {
                        src: "/portal/main.js",
                        type: "text/javascript"
                    }
                ])
            } else {
                injectedScripts = injectedScripts.concat([
                    {
                        src: "/portal/main.js",
                        type: "text/javascript"
                    }
                ]);
            }
        } else {
            injectedScripts = injectedScripts.concat([
                {
                    src: "/lib/jsstore/worker_function.js",
                    type: "text/javascript"
                },
                {
                    src: "/lib/jsstore/jsstore.min.js",
                    type: "text/javascript"
                },
                {
                    src: "/portal/main.js",
                    type: "text/javascript"
                }
            ]);
        }
        let _hata = 0;
        for (let index = 0; index < injectedScripts.length; index++) {
            await new Promise((resolve1, reject1) => {
                let sc = document.createElement('script');
                sc.onload = function () {
                    this.remove();
                    resolve1(true);
                };
                sc.onerror = function (e) {
                    if (_hata < 8) {
                        index--;
                        _hata++
                    } else {
                        window.location.reload();
                    }
                };

                sc.src = chrome.runtime.getURL(injectedScripts[index].src);
                sc.type = injectedScripts[index].type;
                (document.body || document.documentElement).appendChild(sc);
            })
        }
        menu.style.display = "unset";
        resolve(true);

    })
}

function kvkkBilgilendirme() {
    return new Promise(async (resolve, reject) => {
        let onayliyorum = document.createElement('div');
        onayliyorum.innerText = 'Evet';
        onayliyorum.className = "button positive";
        onayliyorum.onfunc = async function (params) {
            user_dialog.hide();
            chrome.runtime.sendMessage({
                ask: "kvkkCevabi",
                params: {
                    avukat_id: user.avukat_id,
                    avukat_adi: user.avukat_adi,
                    avukat_soyadi: user.avukat_soyadi,
                    kvkkCevap: true,
                },
            });
            return true;

        }
        let onaylamiyorum = document.createElement('div');
        onaylamiyorum.innerText = 'Hayır';
        onaylamiyorum.className = "button";
        onaylamiyorum.onfunc = async function (params) {
            chrome.runtime.sendMessage({
                ask: "kvkkCevabi",
                params: {
                    avukat_id: user.avukat_id,
                    kvkkCevap: false,
                },
            });
            user_dialog.hide();
            return false;
        }
        let center = {
            mesaj: `
        <p style="clear:both" xmlns="http://www.w3.org/1999/html"><span style="display: block;text-align: center;font-weight: bold;">BİLGİLENDİRME</span>
        <br>
        <p>İMEREK UYAP YARDIMCISI,
        <br>
        <br> 1.IP adresinizi, uygulamanın geliştirilmesinde kullanıcı davranışlarını anlamak için ve istatiksel veri olarak kullanmak üzere,
        <br> 2.Adınızı, Soyadınızı ve Baronuzu kullanıcı ilişkilerinde kullanmak üzere,
        <br>kaydetmektedir.
        <p style="font-weight: bold">(*) Listelenen bilgiler dışında başka hiçbir verinize <span style="text-decoration: underline;">ulaşmıyor veya kaydetmiyoruz.</span></p>
        </p>
<br>
<p>KVKK Aydınlatma metnine ulaşmak için <a href="https://uyap.imerek.com/kvkk_aydinlatma_metni.php" target="_blank">tıklayınız</a></p>
<p>Kullanıcı Sözleşmesine ulaşmak için <a href="https://uyap.imerek.com/kullanici_sozlesmesi.php" target="_blank">tıklayınız</a></p>          
`,
            buttons: [onaylamiyorum, onayliyorum],
        }
        let frf = await user_dialog.show(center);
        resolve(frf);

    });
}

function hosgeldin() {
    return new Promise(resolve => {
        chrome.runtime.sendMessage({
            ask: "odemeBilgileri",
            params: {
                avukat_id: user.avukat_id,
                browser: systemInfo.os.name + "@" + systemInfo.os.version + " - " + systemInfo.browser.name + "@" + systemInfo.browser.version
            },
        }, async function (response) {
            let nextSlide = document.createElement('div');
            nextSlide.innerText = 'Tamam';
            nextSlide.className = "button positive";
            nextSlide.onfunc = async function (params) {
                user_dialog.hide();
                return true;
            }
            let center = {
                mesaj: `
                        <div style="display: flex;justify-content: end;">
                        <div style="margin-top: auto;margin-right: 1em;">
        <span style="float:right;font-size:small">İZMİR BAROSU</span>
        <br>
        <span style="float:right:font-size:small">Baro Sicil No: 16963</span>
        </div>
        <img style="width:55px;align-self:center;float: right"
        src="chrome-extension://hlgcdafdokigonljodongahofoeaedjk/style/img/foto.jpg" />
      
        </div>
        <p style="clear:both">Saygıdeğer Meslektaşım,
        <p>Mesleğimizi icra ederken kullanmakta olduğumuz UYAP AVUKAT PORTALI'nın birkaç ek özellik ile çok daha etkin kullanılabileceğini düşünerek,
        başlangıçta kişisel kullanımım için yapmış olduğum uygulamayı sizlerin de hizmetinize sunmuş bulunmaktayım.
        </p>
        <p>
        Meslek hayatım boyunca kullanmayı planladığım İMEREK UYAP YARDIMCISI'nı sizin değerli görüşleriniz ile birlikte geliştirmeyi ve güncel tutmayı planlıyorum. İrtibat bilgilerim baronun sitesinde ve WHATSAPP destek butonunda bulunmaktadır.
        Soru görüş ve önerilerinizi günün her saati benimle paylaşmanızı istirham ederim.
        </p>
        <p>
        Kullanacağınız İMEREK UYAP YARDIMCISI için derdest dosya başına <strong>KDV dahil yıllık sadece ${response.derdestUcreti} TL</strong> gibi bir ücret ödeyerek programa destek olabilirsiniz.
        </p>
        Sarf edilen emeğin her çeşidine saygı göstereceğinize yürekten inanıyor, iyi çalışmalar diliyorum</p>
        <p>
        <br>
        Saygılarımla,
        <br>
        Av. Ali Hüseyin ERDOĞAN
</p>
        `,
                buttons: [nextSlide],
            }


            user_dialog.show(center).then(de => {
                resolve(de);
            });
        })

    })


}

function uyelikOner() {
    return new Promise(resolve => {
        chrome.runtime.sendMessage({
            ask: "odemeBilgileri",
            params: {
                avukat_id: user.avukat_id,
            },
        }, async function (response) {
            if (response) {

                let nextSlide = document.createElement('div');
                nextSlide.innerText = 'Ödeme Bilgileri';
                nextSlide.className = "btn btn-outline-success-300 btn-sm";
                nextSlide.onfunc = async function (params) {
                    user_dialog.next()
                }
                let ilgilenmiyorum = document.createElement('div');
                ilgilenmiyorum.innerText = 'Daha Sonra';
                ilgilenmiyorum.className = "btn btn-outline-danger btn-sm";
                ilgilenmiyorum.onfunc = function (params) {
                    user_dialog.hide();
                    return 600000;
                }
                let center = {
                    mesaj: `
                        <div style="display: flex;justify-content: end;">
                        <div style="margin-top: auto;margin-right: 1em;">
        <span style="float:right;font-size:small">İZMİR BAROSU</span>
        <br>
        <span style="float:right:font-size:small">Baro Sicil No: 16963</span>
        </div>
        <img style="width:55px;align-self:center;float: right"
        src="chrome-extension://hlgcdafdokigonljodongahofoeaedjk/style/img/foto.jpg" />
      
        </div>
        <p style="clear:both">Saygıdeğer Meslektaşım,
        <p>Mesleğimizi icra ederken kullanmakta olduğumuz UYAP AVUKAT PORTALI'nın birkaç ek özellik ile çok daha etkin kullanılabileceğini düşünerek,
        başlangıçta kişisel kullanımım için yapmış olduğum uygulamayı sizlerin de hizmetinize sunmuş bulunmaktayım.
        </p>
        <p>
        Meslek hayatım boyunca kullanmayı planladığım İMEREK UYAP YARDIMCISI'nı sizin değerli görüşleriniz ile birlikte geliştirmeyi ve güncel tutmayı planlıyorum.
        </p>
        <p>
        Kullanacağınız İMEREK UYAP YARDIMCISI için derdest dosya başına <strong>KDV dahil aylık sadece ${(response.derdestUcreti / 12).toFixed(2)} TL</strong> gibi bir ücret ödeyerek programa destek olabilirsiniz.
        </p>
        
        <p>Söz konusu ücreti ödeyemeyecek durumda olan meslektaşlarım baro levhasında kayıtlı cep telefonumdan bana ulaşarak ücretsiz kullanma talebinde bulunmaları halinde kendilerine yardımcı olacağımı belirtmek isterim. 
        <br>
        Sarf edilen emeğin her çeşidine saygı göstereceğinize yürekten inanıyor, iyi çalışmalar diliyorum</p>
        `,
                    buttons: [ilgilenmiyorum, nextSlide],
                }
                let prevSlide = document.createElement('div');
                prevSlide.innerText = 'Önceki Sayfa';
                prevSlide.className = "btn btn-outline-success-300 btn-sm";
                prevSlide.onfunc = async function (params) {
                    user_dialog.prev();
                }
                let contactWP = document.createElement('div');
                contactWP.innerHTML = `<a target="_blank" style="border: none"
                                         href="https://wa.me/905056155416?text=Say%C4%B1n%20Meslekta%C5%9F%C4%B1m%3B%0A"
                                         data-action="share/whatsapp/share"
                                         title="Bize Ulaşın"><img style="width: 2em;"
                                                                  src="chrome-extension://hlgcdafdokigonljodongahofoeaedjk/style/img/whatsapp.png"> </a>İletişim`;
                contactWP.className = "button";
                let ekSure = document.createElement('div');
                ekSure.innerText = 'Ödeme Sayfası';
                ekSure.className = "btn btn-outline-danger btn-sm";
                ekSure.onfunc = function (params) {
                    user_dialog.hide();
                    return new Promise((resolve2, reject) => {
                        const myGallery = GLightbox({
                            elements: [
                                {
                                    'href': 'https://odeme.imerek.com/index.php?avukat_id=' + user.avukat_id + '&cSa=' + user._cSa,
                                }
                            ],
                            draggable: false,
                            closeOnOutsideClick: false,
                            zoomable: false,
                            preload: false
                        });
                        myGallery.on('close', () => {
                            resolve2('odeme_sonu');//HALLET ödeme sonucunu döndür
                        });
                        myGallery.open();
                    })
                }
                let inright = {
                    mesaj: `
        <p style="clear:both">
        <br>
        <strong>Derdest Dosya Sayınız : ${response.cSa}</strong>
        <br>
        <br>
        <strong>KDV dahil ${(response.cSa * response.derdestUcreti).toFixed(2)}TL</strong> ödeme karşılığında <strong>bir yıllık</strong> kullanımın hakkınız hesabınıza tanımlanacaktır.
        <br> 
        <br> 
        <strong>Farklı kullanım süreleri ödeme ekranından seçilebilir.</strong>
        <br>
        <br>
        (*)Dilediğiniz zaman üyeliğinizi iptal edebilir, kalan kullanıma ait ücretin iadesini alabilirsiniz.
        <br>
        </p>`,
                    buttons: [contactWP, prevSlide, ekSure]
                }
                let frf = await user_dialog.show(center, inright);

                resolve(frf);

            }
        });
    })
}

function check() {
    return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({
            ask: "check",
            params: {
                avukat_id: user.avukat_id,
                avukat_adi: user.avukat_adi,
                avukat_soyadi: user.avukat_soyadi,
                unique_id: user.unique_id,
                baro: user.baro,
                browser: systemInfo.os.name + "@" + systemInfo.os.version + " - " + systemInfo.browser.name + "@" + systemInfo.browser.version,
                promode: user.options.promode,
                _cSa: user._cSa,
            },
        }, async function (response) {
            if (response) {
                if (response.kvkkSor == true && !document.getElementById("EXT_help")) {
                    await hosgeldin();
                    let kvk = await kvkkBilgilendirme();
                    if (kvk) {
                        resolve(10000);
                        return;
                    } else {
                        resolve(2000);
                        return;
                    }
                }
                if (response.uyap_unique_id === false && !document.getElementById("EXT_help")) {

                    let bugun = new Date();
                    let diffTime = Math.abs(bugun - user.startUp.uyelikOnerTarihi);

                    if (diffTime > 3600000) {
                        let cvrgb = await uyelikOner();
                        user.startUp.uyelikOnerTarihi = new Date();
                        setUserLocal(user.avukat_id);
                        resolve(cvrgb);
                    } else {
                        resolve(2000);
                    }


                } else {
                    resolve(600000);
                }
            } else {
                resolve(10000);
            }


        });

    })
}

let menu = document.createElement('div');
menu.style.display = "none";
menu.innerHTML = `<div class="nav-wrapper">
<a href="#" class="js-nav-toggle" onclick="UYAP_EXT.MENU.MobileMenu.anaMenuButton(this)">
    <span></span>
</a>
<nav role="navigation">
    <div class="nav-toggle">
        <span class="nav-back"></span>
        <span class="nav-title">Menu</span>
        <span class="nav-close"></span>
        <div class="pull-right" title="Uyap Avukat YArdımcısını Duraklat"><i class="fas fa-pause-circle fa-lg"
                onclick="UYAP_EXT.TOOL.disableExtension()"></i></div>
    </div>
    <ul>
        <li class="has-dropdown" data-help onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this);"
            name="menu_item_dosyalar">
            <a href="#" name="badge_yeni_dosyalar">Dosya İşlemleri</a>
            <ul>
                <li data-help name="menu_item_dosya_ara" onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)"><a href="#"
                        onclick="UYAP_EXT.DIALOG.openDosyaAra.default(this)">DOSYA ARA</a></li>
                <li data-help name="menu_item_azilli_dosya" onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)" style="display: none"><a href="#"
                        onclick="UYAP_EXT.DIALOG.openAzilliDosya.default(this)">VEKİL KAYDI SİLİNEN DOSYALAR</a></li>
                <li class="has-dropdown" data-help name="menu_item_yeni_dosyalar" style="display: none"
                    onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)">
                    <a href="#" name="badge_yeni_dosyalar">Yeni Dosyalar</a>
                    <ul>

                        <li><a href="#" name="menu_son_dosyalar" data-yargiTuru="0991"
                                onclick="UYAP_EXT.DIALOG.openYeniDosyalar(this)">Ceza Mahkemeleri</a></li>
                        <li><a href="#" name="menu_son_dosyalar" data-yargiTuru="0992"
                                onclick="UYAP_EXT.DIALOG.openYeniDosyalar(this)">Hukuk Mahkemeleri</a></li>
                        <li><a href="#" name="menu_son_dosyalar" data-yargiTuru="1199"
                                onclick="UYAP_EXT.DIALOG.openYeniDosyalar(this)">İcra Müdürlükleri</a></li>
                        <li><a href="#" name="menu_son_dosyalar" data-yargiTuru="0993"
                                onclick="UYAP_EXT.DIALOG.openYeniDosyalar(this)">İdari Yargı</a></li>
                        <li><a href="#" name="menu_son_dosyalar" data-yargiTuru="9701"
                                onclick="UYAP_EXT.DIALOG.openYeniDosyalar(this)">Satış Memurluğu</a></li>
                        <li><a href="#" name="menu_son_dosyalar" data-yargiTuru="6700"
                                onclick="UYAP_EXT.DIALOG.openYeniDosyalar(this)">Arabuluculuk</a></li>
                        <li><a href="#" name="menu_son_cbs" 
                                onclick="UYAP_EXT.DIALOG.openYeniCbsDosyalar(this)">Cumhuriyet Başsavcılığı</a></li>
                        <li><a href="#" name="menu_son_danistay"
                                onclick="UYAP_EXT.DIALOG.openYeniDanistayDosyalar(this)">Danıştay</a></li>
                        <li><a href="#" name="menu_son_yargitay"
                                onclick="UYAP_EXT.DIALOG.openYeniYargitayDosyalar(this)" data-birimTur3="0">Yargıtay</a>
                        </li>
                        <li class="has-dropdown" data-help name="menu_item_dosya_bildirimleri_temizle"
                    onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)" >
                    <a href="#" style="text-align:center;color:black " >Bildirimleri Temizle</a>
                    <ul>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="0991"
                                class="checkbox" checked>
                            <span>Ceza Mahkemeleri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="0992"
                                class="checkbox" checked>
                            <span>Hukuk Mahkemeleri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="1199"
                                class="checkbox" checked>
                            <span>İcra Müdürlükleri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="0993"
                                class="checkbox" checked>
                            <span>İdari Yargı</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="9701"
                                class="checkbox" checked>
                            <span>Satış Memurluğu</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="6700"
                                class="checkbox" checked>
                            <span>Arabuluculuk</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="cbs" class="checkbox" checked>
                            <span>Cumhuriyet Başsavcılığı</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="danistay" class="checkbox" checked>
                            <span>Danıştay</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="yargitay" class="checkbox" checked>
                            <span>Yargıtay</span>
                        </li>
                        
                        <li style="padding:0.3em 0.7em;color: #333;;text-align:right" data-help name="menu_item_dosya_bildirimleri_temizle_son"
                            onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)">
                            <a href="#" onclick="UYAP_EXT.TOOL.dosyaBildirimTemizle(this)">Bildirimleri Temizle</a>
                        </li>
                    </ul>

                </li>
                    </ul>
                </li>
                <li class="has-dropdown" data-help name="menu_item_yeni_dosya_kontrolu_yap"
                    onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)">
                    <a href="#">Yeni Dosya Kontrolü Yap</a>
                    <ul>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="0"
                                class="checkbox" checked>
                            <span for="ceza_mahkemeleri">Ceza Mahkemeleri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="1"
                                class="checkbox" checked>
                            <span>Hukuk Mahkemeleri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="2"
                                class="checkbox" checked>
                            <span>İcra Müdürlükleri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="6"
                                class="checkbox" checked>
                            <span>İdari Yargı</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="11"
                                class="checkbox" checked>
                            <span>Satış Memurluğu</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="25"
                                class="checkbox" checked>
                            <span>Arabuluculuk</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="cbs" value="0" class="checkbox" onchange="UYAP_EXT.DIALOG.cbsDosyaSorgulaOnchange(this)"
                                >
                            <span>Cumhuriyet Başsavcılığı</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="danistay" value="0"
                                class="checkbox" checked>
                            <span>Danıştay</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="yargitay" value="0"
                                class="checkbox" checked>
                            <span>Yargıtay</span>
                        </li>
                        <li style="padding: 0.3em 0.7em;display: flex;justify-content: center;column-gap: 10px;color: #333;">
                             <div>
                            <input type="checkbox" name="acik" class="checkbox" style="float:unset" checked><span>Açık
                                Dosyalar</span>
                                </div>
                             <div>
                            <input type="checkbox" name="kapali" class="checkbox" style="float:unset"
                                data-kapalitakipet="true"
                                onclick="UYAP_EXT.MENU.MobileMenu.inputKapaliTakipet(this)"><span>Kapalı
                                Dosyalar</span>
                                </div>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;;text-align:right" data-help name="menu_item_yeni_dosyalarimi_al"
                            onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)">
                            <a href="#" onclick="UYAP_EXT.TOOL.tasksRequests.dosyalariEsitle(this)">Yeni Dosyalarımı
                                Bul</a>
                        </li>
                    </ul>
                </li>
                <li class="has-dropdown" data-help name="menu_item_icra_islemleri" style="display: none"
                    onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)">
                    <a href="#">Toplu İcra Sorgula</a>
                    <ul>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="icra" 
                                class="checkbox" checked>
                            <span >Kamu Çalışanı Bilgileri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="icra"
                                class="checkbox" checked>
                            <span>Kamu Emekli Bilgileri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="icra"
                                class="checkbox" checked>
                            <span>SSK Çalışanı Bilgileri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="icra"
                                class="checkbox" checked>
                            <span>SSK Emekli Bilgileri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="icra"
                                class="checkbox" checked>
                            <span>SGK/BAĞKUR Çalışanı Bilgileri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="icra"
                                class="checkbox" checked>
                            <span>SGK/BAĞKUR Emekli Bilgileri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="icra"
                                class="checkbox" checked>
                            <span>EGM</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="icra" 
                                class="checkbox" checked>
                            <span>Posta Çeki</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="icra" 
                                class="checkbox" checked>
                            <span>TAKBİS</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="icra" 
                                class="checkbox" checked>
                            <span>SGK Haciz Bilgileri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="icra" 
                                class="checkbox" checked>
                            <span>İcra Dosyası Bilgileri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="icra" 
                                class="checkbox" checked>
                            <span>Banka Bilgileri</span>
                        </li>
                        
                        <li style="padding:0.3em 0.7em;color: #333;;text-align:right" data-help name="menu_item_yeni_dosyalarimi_al"
                            onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)">
                            <a href="#" onclick="UYAP_EXT.TOOL.tasksRequests.dosyalariEsitle(this)">Borçlu Bilgilerini Güncelle</a>
                        </li>
                    </ul>
                </li>
                <li data-help name="menu_item_dosya_sync" onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this);"><a
                        href="#" onclick="UYAP_EXT.TOOL.tasksRequests.sycnArchivefiles.loopSync(this);">Yerel Arşivi
                        Eşitle</a></li>
            </ul>
        </li>
        <li class="has-dropdown" data-help name="menu_item_evraklar"
            onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)">
            <a href="#" name="badge_yeni_evraklar">Evrak İşlemleri</a>
            <ul>
                <li data-help name="menu_item_evrak_ara" onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)"><a href="#"
                        onclick="UYAP_EXT.DIALOG.openEvrakAra.default(this)">EVRAK ARA</a></li>
                <li class="has-dropdown" data-help name="menu_item_yeni_evraklar" style="display: none"
                    onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)">
                    <a href="#" name="badge_yeni_evraklar">Yeni Evraklar</a>
                    <ul>

                        <li><a href="#" name="menu_son_evraklar" data-birimTur3="0991"
                                onclick="UYAP_EXT.DIALOG.openYeniEvraklar(this)">Ceza Mahkemeleri</a></li>
                        <li><a href="#" name="menu_son_evraklar" data-birimTur3="0992"
                                onclick="UYAP_EXT.DIALOG.openYeniEvraklar(this)">Hukuk Mahkemeleri</a></li>
                        <li><a href="#" name="menu_son_evraklar" data-birimTur3="1199"
                                onclick="UYAP_EXT.DIALOG.openYeniEvraklar(this)">İcra Müdürlükleri</a></li>
                        <li><a href="#" name="menu_son_evraklar" data-birimTur3="0993"
                                onclick="UYAP_EXT.DIALOG.openYeniEvraklar(this)">İdari Yargı</a></li>
                        <li><a href="#" name="menu_son_evraklar" data-birimTur3="9701"
                                onclick="UYAP_EXT.DIALOG.openYeniEvraklar(this)">Satış Memurluğu</a></li>
                        <li><a href="#" name="menu_son_evraklar" data-birimTur3="6700"
                                onclick="UYAP_EXT.DIALOG.openYeniEvraklar(this)">Arabuluculuk</a></li>
                        <li><a href="#" name="menu_son_cbs_evraklar"
                                onclick="UYAP_EXT.DIALOG.openYeniCbsEvraklar(this)">Cumhuriyet Başsavcılığı</a></li>
                        <li><a href="#" name="menu_son_danistay_evraklar"
                                onclick="UYAP_EXT.DIALOG.openYeniDanistayEvraklar(this)">Danıştay</a></li>
                        <li><a href="#" name="menu_son_yargitay_evraklar"
                                onclick="UYAP_EXT.DIALOG.openYeniYargitayEvraklar(this)" data-birimTur3="0">Yargıtay</a>
                        </li>
                        <li class="has-dropdown" data-help name="menu_item_evrak_bildirimleri_temizle"
                    onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)" >
                    <a href="#" style="text-align:center;color:black " >Bildirimleri Temizle</a>
                    <ul>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="0991"
                                class="checkbox" checked>
                            <span>Ceza Mahkemeleri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="0992"
                                class="checkbox" checked>
                            <span>Hukuk Mahkemeleri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="1199"
                                class="checkbox" checked>
                            <span>İcra Müdürlükleri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="0993"
                                class="checkbox" checked>
                            <span>İdari Yargı</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="9701"
                                class="checkbox" checked>
                            <span>Satış Memurluğu</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="6700"
                                class="checkbox" checked>
                            <span>Arabuluculuk</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="cbs" class="checkbox" checked>
                            <span>Cumhuriyet Başsavcılığı</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="danistay" class="checkbox" checked>
                            <span>Danıştay</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="yargitay" class="checkbox" checked>
                            <span>Yargıtay</span>
                        </li>
                        
                        <li style="padding:0.3em 0.7em;color: #333;;text-align:right" data-help name="menu_item_evrak_bildirimleri_temizle_son"
                            onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)">
                            <a href="#" onclick="UYAP_EXT.TOOL.evrakBildirimTemizle(this)">Bildirimleri Temizle</a>
                        </li>
                    </ul>

                </li>
                    </ul>

                </li>

                <li class="has-dropdown" data-help name="menu_item_yeni_evrak_kontrolu_yap"
                    onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)">
                    <a href="#">Yeni Evrak Kontolü Yap</a>
                    <ul>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="0991"
                                class="checkbox" checked>
                            <span>Ceza Mahkemeleri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="0992"
                                class="checkbox" checked>
                            <span>Hukuk Mahkemeleri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="1199"
                                class="checkbox" checked>
                            <span>İcra Müdürlükleri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="0993"
                                class="checkbox" checked>
                            <span>İdari Yargı</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="9701"
                                class="checkbox" checked>
                            <span>Satış Memurluğu</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="6700"
                                class="checkbox" checked>
                            <span>Arabuluculuk</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="cbs" class="checkbox" checked>
                            <span>Cumhuriyet Başsavcılığı</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="danistay" class="checkbox" checked>
                            <span>Danıştay</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="yargitay" class="checkbox" checked>
                            <span>Yargıtay</span>
                        </li>
                        <li style="display:none; padding:0.3em 0.7em;color: #333;" data-help name="menu_item_yeni_safahatli_evraklar">
                            <input type="checkbox" name="safahatliEvraklar" class="checkbox"
                                onclick="UYAP_EXT.MENU.MobileMenu.safahatliEvrakSorgula(this)"><span>Sadece Son 2 Hafta</span>  
                        </li>
                        <li style="padding: 0.3em 0.7em;display: flex;justify-content: center;column-gap: 10px;color: #333;">
                            <div>
                            <input type="checkbox" name="acik" class="checkbox" style="float:unset" checked><span>Açık
                                Dosyalar</span>
                            
                            </div>
                            <div>
                            <input type="checkbox" name="kapali" class="checkbox" style="float:unset"
                                data-kapalitakipet="true"
                                onclick="UYAP_EXT.MENU.MobileMenu.inputKapaliTakipet(this)"><span>Kapalı
                                Dosyalar</span>
                            
                            </div>
                            
                        </li>
                        
                        <li style="padding:0.3em 0.7em;color: #333;;text-align:right" data-help name="menu_item_yeni_evraklarimi_al"
                            onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)">
                            <a href="#" onclick="UYAP_EXT.TOOL.tasksRequests.evraklariEsitle.esitle()">Yeni Evraklarımı
                                Bul</a>
                        </li>
                    </ul>
                </li>

            </ul>
        </li>
        <li class="has-dropdown" data-help name="menu_item_tebligatlar"
            onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)">
            <a href="#" name="badge_yeni_tebligatlar">Tebligat İşlemleri</a>
            <ul>
                <li data-help name="menu_item_tebellug" style="display: none"
                    onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)"><a name="menu_son_tebellug" href="#"
                        onclick="UYAP_EXT.MENU.gorulmemisTebellugler(this)">Tebellüğ Ettiklerim</a></li>
                <li data-help name="menu_item_geri_teblig" style="display: none"
                    onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)"><a name="menu_son_geri_teblig" href="#"
                        onclick="UYAP_EXT.MENU.gorulmemisTebligdekiler(this)">Tebligata Çıkarılanlar</a></li>
                <li data-help name="menu_item_harici_tebligatlar"
                    onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)"><a name="menu_son_harici_tebligatlar" href="#"
                        onclick="UYAP_EXT.DIALOG.openHariciTebligatlar.default(this)">Harici Tebligatlar</a></li>
                <li data-help name="menu_item_hatali_tebligat" style="display: none"
                    onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)"><a name="menu_son_item_hatali_tebligat" href="#"
                        onclick="UYAP_EXT.DIALOG.openHataliTebligatList.default(this)">İçeriği Okunamayan
                        Tebligatlar</a></li>
                <li class="has-dropdown" data-help name="menu_item_tebligat_kontrol"
                    onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)">
                    <a href="#">Tebligatları Kontrol Et</a>
                    <ul>
                       
                        <li style="padding:0.3em 0.7em;color: #333;;text-align:center">
                            UYAP Yardımcınız, Tebligatların Tespitini ve Kontrolünü Otomatik Şekilde Yaparak Sonucu
                            Hakkında Sizi Bilgilendirir
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li class="has-dropdown" data-help name="menu_item_muhasebe" style="display: none"
            onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)">
            <a href="#" onclick="UYAP_EXT.MENU.muvekkilList.hazirla(this)">Muhasebe (Beta Sürüm)</a>
            <ul>
                <li class="has-dropdown"><a name="menu_son_muvekkil_muhasebe" href="#">Müvekkil Muhasebesi</a>
                    <ul style="overflow-x: scroll;height: calc(100% - 9em)" id="menu_muvekkiller_list">
                        <li>
                            <fieldset class="field-container">
                                <input oninput="UYAP_EXT.MENU.muvekkilList.search(this)" type="text"
                                    placeholder="Ara..." class="field" />
                                <div class="icons-container">
                                    <div class="icon-search"></div>
                                    <div onclick="document.querySelector('input.field').value='';UYAP_EXT.MENU.muvekkilList.search(document.querySelector('input.field'))"
                                        class="icon-close">
                                        <div class="x-up"></div>
                                        <div class="x-down"></div>
                                    </div>
                                </div>
                            </fieldset>
                        </li>
                    </ul>
                </li>
                <li><a name="menu_son_dosya_muhasebe" href="#"
                        onclick="UYAP_EXT.DIALOG.openMuhasebeDosyalar.default(this)">Dosya Muhasebesi</a></li>
                <li class="has-dropdown" data-help name="menu_item_odemeler_konrtol"
                    onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)">
                    <a href="#">Ödeme ve Taraf Bilgilerini Güncelle</a>
                    <ul>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="0991"
                                class="checkbox" checked>
                            <span>Ceza Mahkemeleri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="0992"
                                class="checkbox" checked>
                            <span>Hukuk Mahkemeleri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="1199"
                                class="checkbox" checked>
                            <span>İcra Müdürlükleri</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="0993"
                                class="checkbox" checked>
                            <span>İdari Yargı</span>
                        </li>
                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="dosyalar" value="9701"
                                class="checkbox" checked>
                            <span>Satış Memurluğu</span>
                        </li>

                        <li style="padding:0.3em 0.7em;color: #333;"><input type="checkbox" name="danistay" class="checkbox" checked>
                            <span>Danıştay</span>
                        </li>
                        <li style="padding: 0.3em 0.7em;display: flex;justify-content: center;column-gap: 10px;color: #333;">
                            <div>
                            <input type="checkbox" name="acik" class="checkbox" style="float:unset" checked><span>Açık
                                Dosyalar</span>
                            </div>
                            <div>
                            <input type="checkbox" name="kapali" class="checkbox" style="float:unset"
                                data-kapalitakipet="false"
                                onclick="UYAP_EXT.MENU.MobileMenu.inputKapaliTakipet(this)"><span>Kapalı
                                Dosyalar</span>            
                            </div>
                            
                        </li>
                        <li data-help name="menu_item_odemeleri_kontrol_et" style="padding:0.3em 0.7em;color: #333;;text-align:right"
                            onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)">
                            <a href="#" onclick="UYAP_EXT.TOOL.tasksRequests.odemeleriEsitle(this)">
                                Güncelle
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>


        </li>
        <li data-help name="menu_item_islemlerim" style="display: none"
            onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)">
            <a href="#" name="devam_eden_islemlerim" onclick="UYAP_EXT.DIALOG.openDevamedenIslemlerim(this)">Devam
                Eden İşlemlerim</a>

        </li>
        <li data-help name="menu_item_notlarim" style="display: none"
            onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)"><a href="#"
                onclick="UYAP_EXT.DIALOG.openNotlarim.default(this)">Notlarım</a></li>
        <li class="has-dropdown" data-help name="menu_item_yedekleme"
            onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)">
            <a href="#" name="sistem_yedekleme">Yedekle/Geri Yükle</a>
            <ul>
                <li data-help name="menu_item_yedekle" onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)"><a href="#"
                        onclick="UYAP_EXT.TOOL.backup.dump();">Yedekle</a></li>
                <li data-help name="menu_item_geri_yukle" onclick="UYAP_EXT.MENU.MobileMenu.liDataHelp(this)"><a
                        href="#" onclick="UYAP_EXT.TOOL.backup.restore();">Geri
                        Yükle</a></li>
            </ul>
        </li>
        <li><a class="ayarlar" href="#" onclick="UYAP_EXT.DIALOG.openAyarlar.default(this)">Ayarlar</a></li>
    </ul>

    <div id="temasnoktasi"
        style="opacity: 0.5;position: absolute;display: flex;bottom: 4em;left:calc(150px - 4.4em);width: 8.8em;justify-content: center;">
        <div class="popover__wrapper">
  <a id="bizeulasin" 
             title="Bize Ulaşın"><img style="width: 3em;cursor: pointer"
                src="chrome-extension://hlgcdafdokigonljodongahofoeaedjk/style/img/customer.svg"></a>
          <div class="popover__content" style="top:calc(-3em - 18px);left:-4.5em;">
        <a target="_blank" style="border: none" 
            href="https://wa.me/905056155416?text=Say%C4%B1n%20Meslekta%C5%9F%C4%B1m%3B%0A"
            data-action="share/whatsapp/share"
             title="Bize Ulaşın"><img style="width: 3em;"
                src="chrome-extension://hlgcdafdokigonljodongahofoeaedjk/style/img/whatsapp.png"> </a>
                <a style="border: none;" href="mailto:uyap@imerek.com?subject=İMEREK UYAP Yardımcısı Hakkında&amp;"
            title="Bize Ulaşın"><img style="width: 3em;"
                src="chrome-extension://hlgcdafdokigonljodongahofoeaedjk/style/img/email.png"> </a>
                <a target="_blank" style="border: none;" href="http://uyap.imerek.com" title="Bize Ulaşın"><img
                style="width: 3em;" src="chrome-extension://hlgcdafdokigonljodongahofoeaedjk/style/img/web-icon.svg">
        </a>
  </div>      
             
  
</div>
        
    </div>
</nav>
</div>`;
menu.id = 'hamburger';
document.body.appendChild(menu);
let dialog = document.createElement("div");
dialog.innerHTML = `<input type="checkbox" name="dialog_state" class="dialog_state" onchange="UYAP_EXT.DIALOG.user_dialog.onchange(this,false)">
            <div class="dialog" id="user_dialog_wrapper">
                <div class='dlg-wrap'>
                    <div class='dlg-content center'>
            <div class='mesaj'>
            
            </div>
                        <div class='dlg-prompt'>
                            
                        </div>
                    </div>
                    <div class='dlg-content inright'>
                    <div class='mesaj'>
            
                    </div>
                        <div class='dlg-prompt'>
                            
                        </div>
                    </div>
                </div>
                </div>
                
    
                `
document.body.appendChild(dialog);
document.body.insertAdjacentHTML("afterbegin", `
                <div  id="tebligatNotify" style="display: none"><input type="checkbox" id="tebligatNotifyCheck">
    <label for="tebligatNotifyCheck">
      <i class="fas fa-envelope animate__animated animate__headShake animate__infinite animate__slow animate__repeat-3"  id="notifyleft"></i>
      <i class="fas fa-chevron-circle-right" id="notifyright"></i>
    </label>
    <div id="tebligat_sidebar" ></div></div>`);
document.querySelector('.nav-wrapper').addEventListener('transitionend', async function () {
    document.getElementById("campaigns").className = "animate__tada animate__infinite animate__animated animate__slow animate__repeat-1";
    /*
    if (requests.check.length == 0) {
        if (!(user.avukat_id >= 0)) {
            window.location.reload();
            return 0;
        }
        if (user._cSa == null) {
            return 0;
        }
        requests.check.push(check());
        requests.check[0].then((derr) => {
            if (!isNaN(derr)) {
                setTimeout(() => {
                    requests.check = [];
                }, derr);
            }


        });

    }

 */

});

var startUpScripts = [
    "/portal/startup.js"
];
new Promise(async (resolve, reject) => {
    let _hata = 0;
    for (let index = 0; index < startUpScripts.length; index++) {
        await new Promise((resolve1, reject1) => {
            let sc = document.createElement('script');
            sc.onload = function () {
                this.remove();
                resolve1(true);
            };
            sc.onerror = function (e) {
                if (_hata < 8) {
                    index--;
                    _hata++
                } else {
                    window.location.reload();
                }
            };
            sc.src = chrome.runtime.getURL(startUpScripts[index]);
            (document.head || document.documentElement).appendChild(sc);
        })
    }
    resolve(true);
})
