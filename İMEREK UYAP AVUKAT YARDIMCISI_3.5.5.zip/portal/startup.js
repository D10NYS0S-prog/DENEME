
function startUp(){

    return true;
   
}
if(startUp()){
    new Promise((resolve, reject) => {
        let started=false;
        let dedeff = setTimeout(function () {
            window.location.reload();
        }, 15000);
        var xhttp = new XMLHttpRequest();
        xhttp.open("POST", "/avukatKisiselBilgileriSorgula.ajx", true);
        xhttp.setRequestHeader("Content-Type", 'application/json');
        xhttp.setRequestHeader('Accept', 'application/json, text/plain, */*');
        xhttp.setRequestHeader('cache-control','no-cache');
        xhttp.setRequestHeader('Expires',"0");
        xhttp.onreadystatechange = function() {
            if ((this.readyState > 2) && this.status == 200 && started==false && xhttp.responseText.length>0) {
                let data=[{}];
                
                try {
                    data=JSON.parse(xhttp.responseText);
                }catch (e) {
                    data[0].avukatId=parseInt(/"avukatId":(.*?),/g.exec(xhttp.responseText)[1]);
                    data[0].ad= /"ad":"(.*?)",/g.exec(xhttp.responseText)[1];
                    data[0].soyad= /"soyad":"(.*?)",/g.exec(xhttp.responseText)[1];
                    data[0].bagliOlduguBaroAdi= /"bagliOlduguBaroAdi":"(.*?)",/g.exec(xhttp.responseText)[1];
                }
                if(data.error){
                    clearTimeout(dedeff);
                    reject(data);
                }else{
                    if (Number.isInteger(parseInt(data[0].avukatId)) && data[0].avukatId > 0) {
                        clearTimeout(dedeff);
                        started=true
                        resolve(data);
                    }else {
                        reject(data);
                    }
                }


            }
        };
        xhttp.send("{}");
    }).then(kimlik => {
        const channel = new MessageChannel();
        channel.port1.onmessage = ({data}) => {
            channel.port1.close();
            if(window.location.href != "https://avukatbeta.uyap.gov.tr/"&&window.location.href !="https://avukatbeta.uyap.gov.tr/giris"){
                window.location.href = "https://avukatbeta.uyap.gov.tr/";
            }

            //VERSION cevaba göre hareket edebilirsin
        };
        if (typeof window.UYAP_EXT == "undefined") {
            window.UYAP_EXT = {
                GENEL:{
                    kimlikBilgileri:kimlik[0]
                }
            };
        }else{
            UYAP_EXT.GENEL={
                kimlikBilgileri:kimlik[0]
            }
        }
        window.postMessage({ask:"startup",params:{id:kimlik[0].avukatId,adi:kimlik[0].ad,soyadi: kimlik[0].soyad,baro:kimlik[0].bagliOlduguBaroAdi}},"*", [channel.port2]);

    }).catch(dsd=>{
        console.log(dsd);
        alert("UYAP Avukat Portaldan Kaynaklanan Bir Hata Sebebi İle İMEREK Başlatılamadı.")
    });
}

